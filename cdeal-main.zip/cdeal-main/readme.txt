hey this project needs some installations to run:
1) flask
2) selenium
3) beautiful soup
4) pyrebase
5) firebase_admin
you can do pip install requirments.txt


# for webdriver you need to set chrome webdriver path 
https://www.youtube.com/watch?v=WnWQgUerR0c


# some field requires creditional i have removed mine:

eg. send_mail.py

